# V2bX Auto Install Script 📦

此脚本用于自动化部署：

- 启用 Root 登录；
- 安装 unzip 和 zip；
- 下载并启动 V2bX；
- 注册并启用 systemd 服务；
- 安装 nyanpass 客户端；
- 安装哪吒 Agent 并设置每 60 秒上报。

## 一键安装命令

```bash
bash <(curl -fsSL https://gist.githubusercontent.com/你的用户名/GIST_ID/raw/install.sh)
```

请将 `GIST_ID` 替换为你创建的 Gist ID。
